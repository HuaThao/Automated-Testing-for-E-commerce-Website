package WebDriver;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.Duration;
import java.util.List;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

public class TestLoginLogout {
	WebDriver driver;

	@BeforeEach
	public void setUp() {
		System.setProperty("webdriver.edge.driver", "D:/msedgedriver/msedgedriver.exe");
		driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("http://127.0.0.1:8000");
	}

	@Test
	@Order(1)
	public void testChuyenTrangDN() throws InterruptedException {
		System.out.println("Test chuyển trang...");
		Thread.sleep(2000); // Nghỉ 2 giây
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement iconPerson = driver.findElement(By.xpath("//a[@class='header__account--btn preson']"));
		iconPerson.click();

		String expectedUrl = "http://127.0.0.1:8000/auth";

		try {
			WebElement emailField = wait
					.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Email']")));
			assertNotNull(emailField, "Chuyển đúng vào trang đang nhập");
			System.out.println("Không có BUG.");
		} catch (Exception e) {
			System.out.println("BUG: Không chuyển vào đúng trang đăng nhập.");
		}
	}

	@Test
	@Order(2)
	public void testInputEmail() throws InterruptedException {
		System.out.println("Test Nhập Email...");
		Thread.sleep(2000); // Nghỉ 2 giây
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement iconPerson = driver.findElement(By.xpath("//a[@class='header__account--btn preson']"));
		iconPerson.click();
		WebElement usernameField = driver.findElement(By.xpath("//input[@placeholder='Email']"));
		usernameField.sendKeys("");

		WebElement passwordField = driver.findElement(By.xpath("//input[@placeholder='Password']"));
		passwordField.sendKeys("123456");

		WebElement loginButton = driver.findElement(By.xpath("//button[@class='account__login--btn primary__btn']"));
		loginButton.click();
		try {
			WebElement errorMessage = wait
					.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='toast-message']")));
			// Kiểm tra nội dung của thông báo lỗi
			String expectedMessage = "Tài khoản hoặc mật khẩu không đúng";
			String actualMessage = errorMessage.getText();
			if (actualMessage.equals(expectedMessage)) {
				System.out.println("Không có bug. Thông báo lỗi hiển thị đúng: " + actualMessage);
			}
		} catch (Exception e) {
			System.out.println("BUG: Không hiển thị thông báo lỗi" + e.getMessage());
		}

	}

	@Test
	@Order(3)
	public void testInputEmailFail() throws InterruptedException {
		System.out.println("Test Nhập Email...");
		Thread.sleep(2000); // Nghỉ 2 giây
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement iconPerson = driver.findElement(By.xpath("//a[@class='header__account--btn preson']"));
		iconPerson.click();
		WebElement usernameField = driver.findElement(By.xpath("//input[@placeholder='Email']"));
		usernameField.sendKeys("nguyenvanthuan@gmail.com");

		WebElement passwordField = driver.findElement(By.xpath("//input[@placeholder='Password']"));
		passwordField.sendKeys("123456");

		WebElement loginButton = driver.findElement(By.xpath("//button[@class='account__login--btn primary__btn']"));
		loginButton.click();
		try {
			WebElement errorMessage = wait
					.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='toast-message']")));
			// Kiểm tra nội dung của thông báo lỗi
			String expectedMessage = "Tài khoản hoặc mật khẩu không đúng";
			String actualMessage = errorMessage.getText();
			if (actualMessage.equals(expectedMessage)) {
				System.out.println("Không có bug. Thông báo lỗi hiển thị đúng: " + actualMessage);
			}
		} catch (Exception e) {
			System.out.println("BUG: Không hiển thị thông báo lỗi" + e.getMessage());
		}

	}

	@Test
	@Order(4)
	public void testInputPassword() throws InterruptedException {
		System.out.println("Test Nhập Password...");
		Thread.sleep(2000); // Nghỉ 2 giây
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement iconPerson = driver.findElement(By.xpath("//a[@class='header__account--btn preson']"));
		iconPerson.click();
		WebElement usernameField = driver.findElement(By.xpath("//input[@placeholder='Email']"));
		usernameField.sendKeys("huavanthao20102016@gmail.com");

		WebElement passwordField = driver.findElement(By.xpath("//input[@placeholder='Password']"));
		passwordField.sendKeys("");

		WebElement loginButton = driver.findElement(By.xpath("//button[@class='account__login--btn primary__btn']"));
		loginButton.click();
		try {
			WebElement errorMessage = wait
					.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='toast-message']")));
			// Kiểm tra nội dung của thông báo lỗi
			String expectedMessage = "Tài khoản hoặc mật khẩu không đúng";
			String actualMessage = errorMessage.getText();
			if (actualMessage.equals(expectedMessage)) {
				System.out.println("Không có bug. Thông báo lỗi hiển thị đúng: " + actualMessage);
			}
		} catch (Exception e) {
			System.out.println("BUG: Không hiển thị thông báo lỗi" + e.getMessage());
		}

	}

	@Test
	@Order(5)
	public void testInputPasswordFail() throws InterruptedException {
		System.out.println("Test Nhập Password...");
		Thread.sleep(2000); // Nghỉ 2 giây
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement iconPerson = driver.findElement(By.xpath("//a[@class='header__account--btn preson']"));
		iconPerson.click();
		WebElement usernameField = driver.findElement(By.xpath("//input[@placeholder='Email']"));
		usernameField.sendKeys("huavanthao20102016@gmail.com");

		WebElement passwordField = driver.findElement(By.xpath("//input[@placeholder='Password']"));
		passwordField.sendKeys("10599");

		WebElement loginButton = driver.findElement(By.xpath("//button[@class='account__login--btn primary__btn']"));
		loginButton.click();
		try {
			WebElement errorMessage = wait
					.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='toast-message']")));
			// Kiểm tra nội dung của thông báo lỗi
			String expectedMessage = "Tài khoản hoặc mật khẩu không đúng";
			String actualMessage = errorMessage.getText();
			if (actualMessage.equals(expectedMessage)) {
				System.out.println("Không có bug. Thông báo lỗi hiển thị đúng: " + actualMessage);
			}
		} catch (Exception e) {
			System.out.println("BUG: Không hiển thị thông báo lỗi" + e.getMessage());
		}

	}

	@Test
	@Order(6)
	public void testLogin() throws InterruptedException {
		System.out.println("Test Đăng Nhập...");
		Thread.sleep(2000); // Nghỉ 2 giây
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement iconPerson = driver.findElement(By.xpath("//a[@class='header__account--btn preson']"));
		iconPerson.click();

		WebElement usernameField = driver.findElement(By.xpath("//input[@placeholder='Email']"));
		usernameField.sendKeys("huavanthao20102016@gmail.com");

		WebElement passwordField = driver.findElement(By.xpath("//input[@placeholder='Password']"));
		passwordField.sendKeys("123456");

		WebElement loginButton = driver.findElement(By.xpath("//button[@class='account__login--btn primary__btn']"));
		loginButton.click();
		
		try {
			WebElement errorMessage = wait
					.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='toast-message']")));
			// Kiểm tra nội dung của thông báo lỗi
			String expectedMessage = "Đã đăng nhập thành công";
			String actualMessage = errorMessage.getText();
			if (actualMessage.equals(expectedMessage)) {
				System.out.println("Thông báo đăng nhập thành công đúng: " + actualMessage);
			}
			Thread.sleep(2000);
			List<WebElement> homeElement = driver.findElements(By.xpath("//h2[contains(text(), 'SẢN PHẨM PHỔ BIẾN')]"));
		    if (homeElement.isEmpty()) {
		        System.out.println("BUG: Không chuyển qua trang chủ.");
		    }  else {
				System.out.println("Chuyển qua trang chủ thành công .");
			}
		} catch (Exception e) {
			System.out.println("BUG");
		}
	}

	@Test
	@Order(7)
	public void testLogoutProfile() throws InterruptedException {
		System.out.println("Test đăng xuất trong trong trang Thông Tin Cá Nhân");
		Thread.sleep(2000); // Nghỉ 2 giây
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		WebElement iconPerson = driver.findElement(By.xpath("//a[@class='header__account--btn preson']"));
		iconPerson.click();

		WebElement usernameField = driver.findElement(By.xpath("//input[@placeholder='Email']"));
		usernameField.sendKeys("huavanthao20102016@gmail.com");

		WebElement passwordField = driver.findElement(By.xpath("//input[@placeholder='Password']"));
		passwordField.sendKeys("123456");

		WebElement loginButton = driver.findElement(By.xpath("//button[@class='account__login--btn primary__btn']"));
		loginButton.click();

		WebElement iconProfile = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//a[@class='header__account--btn_profile profile']")));
		iconProfile.click();

		WebElement clickLogOut = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(), 'Đăng Xuất')]")));
		clickLogOut.click();

		// Kiểm tra xem đã chuyển về trang chủ có phần "Sản phẩm phổ biến"
		WebElement popularProductsSection = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[@class='section__heading--maintitle']")));

		if (popularProductsSection.isDisplayed()) {
			System.out.println("Đăng xuất thành công với Log Out trong Profile.");
		} else {
			System.err.println("Đăng xuất thất bại hoặc không hiển thị đúng trang chủ.");
		}
	}

	@Test
	@Order(8)
	public void testLogoutIcon() throws InterruptedException {
		System.out.println("Test đăng xuất bằng icon");
		Thread.sleep(2000); // Nghỉ 2 giây
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		WebElement iconPerson = driver.findElement(By.xpath("//a[@class='header__account--btn preson']"));
		iconPerson.click();

		WebElement usernameField = driver.findElement(By.xpath("//input[@placeholder='Email']"));
		usernameField.sendKeys("huavanthao20102016@gmail.com");

		WebElement passwordField = driver.findElement(By.xpath("//input[@placeholder='Password']"));
		passwordField.sendKeys("123456");

		WebElement loginButton = driver.findElement(By.xpath("//button[@class='account__login--btn primary__btn']"));
		loginButton.click();

		WebElement clickLogOut = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='header__account--btn out']")));
		clickLogOut.click();

		// Kiểm tra xem đã chuyển về trang chủ có phần "Sản phẩm phổ biến"
		WebElement popularProductsSection = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[@class='section__heading--maintitle']")));

		if (popularProductsSection.isDisplayed()) {
			System.out.println("Đăng xuất thành công với icon.");
		} else {
			System.err.println("Đăng xuất thất bại hoặc không hiển thị đúng trang chủ.");
		}
	}

	@AfterEach
	public void tearDown() throws InterruptedException {
		Thread.sleep(2000); // Nghỉ 2 giây sau mỗi test
		driver.quit();
	}
}
