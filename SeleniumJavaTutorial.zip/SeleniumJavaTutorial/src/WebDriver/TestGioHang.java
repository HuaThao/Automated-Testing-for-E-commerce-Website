package WebDriver;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.Duration;
import java.util.List;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class TestGioHang {

	WebDriver driver;

	@BeforeEach
	public void setUp() {
		System.setProperty("webdriver.edge.driver", "D:/msedgedriver/msedgedriver.exe");
		driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("http://127.0.0.1:8000");

	}

	@Test
	@Order(1)
	public void testThemSanPhamKhachVangLaiTC() throws InterruptedException {
		System.out.println("Test thêm sản phẩm ở trang chủ của khách vãng lai.");
		Thread.sleep(2000); // Nghỉ 2 giây

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		WebElement addToCart = driver.findElement(By.xpath("//a[@class='product__card--btn primary__btn tsp_01']"));
		addToCart.click();
		try {
			// Chờ thông báo lỗi xuất hiện
			WebElement errorMessage = wait
					.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='toast-title']")));
			// Kiểm tra nội dung của thông báo lỗi
			String expectedMessage = "Thêm sản phẩm không thành công";
			String actualMessage = errorMessage.getText();
			if(actualMessage.equals(expectedMessage)) {
				System.out.println("Hiện thông báo lỗi đúng.");
			} else {
				System.out.println("BUG: Không hiện thông báo lỗi.");
			}

		} catch (Exception e) {
			System.out.println("BUG");
		}
		try {
			List<WebElement> elements = driver.findElements(By.xpath("//input[@placeholder='Email']"));

			if (!elements.isEmpty()) {
				System.out.println("Chuyển qua trang đăng nhập thành công.");
			} else {
				System.out.println("BUG: Không chuyển qua trang đăng nhập.");
			}

		} catch (Exception e) {
			System.out.println("BUG");
		}

	}

	@Test
	@Order(2)
	public void testThemSanPhamKhachVangLaiSP() throws InterruptedException {
		System.out.println("Test thêm sản phẩm ở trang SP của khách vãng lai.");
		Thread.sleep(2000); // Nghỉ 2 giây

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		WebElement clickSP = driver.findElement(By.xpath("//a[@class='header__menu--link text-white SP']"));
		clickSP.click();

		WebElement addToCart = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//a[@class='product__card--btn primary__btn SP']")));
		addToCart.click();
		try {
			// Tìm danh sách các phần tử phù hợp
		    List<WebElement> errorMessages = driver.findElements(By.xpath("//div[contains(text(), 'Thêm sản phẩm không thành công')]"));
		    if (errorMessages.isEmpty()) {
		        System.out.println("BUG: Không hiện thông báo lỗi.");
		    } else {
		        // Lấy thông báo lỗi đầu tiên
		        String actualMessage = errorMessages.get(0).getText();
		        String expectedMessage = "Thêm sản phẩm không thành công";
		        if (actualMessage.equals(expectedMessage)) {
		            System.out.println("Hiện thông báo lỗi đúng.");
		        } else {
		            System.out.println("BUG: Nội dung thông báo lỗi không đúng.");
		        }
		    }
		} catch (Exception e) {
			System.out.println("BUG");
		}
		try {
			WebElement emailField = wait
					.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Email']")));
			assertNotNull(emailField, "Không chuyển đúng vào trang đang nhập");

			if (emailField != null) {
				System.out.println("Chuyển qua trang đăng nhập thành công.");
			} else {
				System.out.println("BUG: Không chuyển qua trang đăng nhập.");
			}

		} catch (Exception e) {
			System.out.println("BUG");
		}

	}
	
	@Test
	@Order(3)
	public void testThemSanPhamKhachVangLaiCT() throws InterruptedException {
		System.out.println("Test thêm sản phẩm ở trang chi tiết của khách vãng lai.");
		Thread.sleep(2000); // Nghỉ 2 giây

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		WebElement clickSP = driver.findElement(By.xpath("//a[@class='product__card--thumbnail__link display-block CT']"));
		clickSP.click();

		WebElement addToCart = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//a[@class='primary__btn quickview__cart--btn add']")));
		addToCart.click();
		try {
			// Tìm danh sách các phần tử phù hợp
		    List<WebElement> errorMessages = driver.findElements(By.xpath("//div[contains(text(), 'Thêm sản phẩm không thành công')]"));
		    if (errorMessages.isEmpty()) {
		        System.out.println("BUG: Không hiện thông báo lỗi.");
		    } else {
		        // Lấy thông báo lỗi đầu tiên
		        String actualMessage = errorMessages.get(0).getText();
		        String expectedMessage = "Thêm sản phẩm không thành công";
		        if (actualMessage.equals(expectedMessage)) {
		            System.out.println("Hiện thông báo lỗi đúng.");
		        } else {
		            System.out.println("BUG: Nội dung thông báo lỗi không đúng.");
		        }
		    }
		} catch (Exception e) {
			System.out.println("BUG");
		}
		try {
			WebElement emailField = wait
					.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Email']")));
			assertNotNull(emailField, "Không chuyển đúng vào trang đang nhập");

			if (emailField != null) {
				System.out.println("Chuyển qua trang đăng nhập thành công.");
			} else {
				System.out.println("BUG: Không chuyển qua trang đăng nhập.");
			}

		} catch (Exception e) {
			System.out.println("BUG");
		}
	}
	
	@Test
	@Order(4)
	public void testThemSanPhamTC() throws InterruptedException {
		System.out.println("Test thêm sản phẩm khi đăng nhập ở trang chủ.");
		Thread.sleep(2000); // Nghỉ 2 giây

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		
        WebElement iconPerson = driver.findElement(By.xpath("//a[@class='header__account--btn preson']"));
        iconPerson.click();

        WebElement usernameField = driver.findElement(By.xpath("//input[@placeholder='Email']"));
        usernameField.sendKeys("huavanthao20102016@gmail.com");

        WebElement passwordField = driver.findElement(By.xpath("//input[@placeholder='Password']"));
        passwordField.sendKeys("123456");

        WebElement loginButton = driver.findElement(By.xpath("//button[@class='account__login--btn primary__btn']"));
        loginButton.click();
        
        Thread.sleep(2000);
        
        WebElement clickTC = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='header__menu--link text-white TC']"))
				);
        clickTC.click();
		
		WebElement addToCart = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='product__card--btn primary__btn tsp_01']"))
				);
		addToCart.click();

		try {
			// Tìm danh sách các phần tử phù hợp
			WebElement toastMessages = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='toast-message']")));
			String expectedMessage = "Đã thêm vào giỏ hàng";
            String actualMessage = toastMessages.getText();
            if (actualMessage.equals(expectedMessage)) {
                System.out.println("Không có bug. Thông báo hiển thị đúng: " + actualMessage);
            } else {
            	System.out.println("BUG: Không hiện thông báo đã thêm vào giỏ hàng");
            }
		} catch (Exception e) {
			System.out.println("BUG");
		}

	}
	
	@Test
	@Order(5)
	public void testThemSanPhamSP() throws InterruptedException {
		System.out.println("Test thêm sản phẩm khi đăng nhập ở trang sản phẩm.");
		Thread.sleep(2000); // Nghỉ 2 giây

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		
        WebElement iconPerson = driver.findElement(By.xpath("//a[@class='header__account--btn preson']"));
        iconPerson.click();

        WebElement usernameField = driver.findElement(By.xpath("//input[@placeholder='Email']"));
        usernameField.sendKeys("huavanthao20102016@gmail.com");

        WebElement passwordField = driver.findElement(By.xpath("//input[@placeholder='Password']"));
        passwordField.sendKeys("123456");

        WebElement loginButton = driver.findElement(By.xpath("//button[@class='account__login--btn primary__btn']"));
        loginButton.click();
        
        Thread.sleep(2000);
        
        WebElement clickTC = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='header__menu--link text-white TC']"))
				);
        clickTC.click();
        
        WebElement clickSP = driver.findElement(By.xpath("//a[@class='header__menu--link text-white SP']"));
		clickSP.click();
		
		WebElement addToCart = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='product__card--btn primary__btn add']"))
				);
		addToCart.click();

		try {
			// Tìm danh sách các phần tử phù hợp
			WebElement toastMessages = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='toast-message']")));
			String expectedMessage = "Đã thêm vào giỏ hàng";
            String actualMessage = toastMessages.getText();
            if (actualMessage.equals(expectedMessage)) {
                System.out.println("Không có bug. Thông báo hiển thị đúng: " + actualMessage);
            } else {
            	System.out.println("BUG: Không hiện thông báo đã thêm vào giỏ hàng");
            }
		} catch (Exception e) {
			System.out.println("BUG");
		}

	}
	
	@Test
	@Order(6)
	public void testThemSanPhamCT() throws InterruptedException {
		System.out.println("Test thêm sản phẩm khi đăng nhập ở trang chi tiết.");
		Thread.sleep(2000); // Nghỉ 2 giây

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		
        WebElement iconPerson = driver.findElement(By.xpath("//a[@class='header__account--btn preson']"));
        iconPerson.click();

        WebElement usernameField = driver.findElement(By.xpath("//input[@placeholder='Email']"));
        usernameField.sendKeys("huavanthao20102016@gmail.com");

        WebElement passwordField = driver.findElement(By.xpath("//input[@placeholder='Password']"));
        passwordField.sendKeys("123456");

        WebElement loginButton = driver.findElement(By.xpath("//button[@class='account__login--btn primary__btn']"));
        loginButton.click();
        
        Thread.sleep(2000);
        
        WebElement clickTC = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='header__menu--link text-white TC']"))
				);
        clickTC.click();
        
        WebElement clickSP = driver.findElement(By.xpath("//a[@class='product__card--thumbnail__link display-block CT']"));
		clickSP.click();
		
		 WebElement clickSL = driver.findElement(By.xpath("//button[@class='quantity__value quickview__value--quantity decrease']"));
			clickSL.click();
		
			Thread.sleep(2000);
			
		WebElement addToCart = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='primary__btn quickview__cart--btn add']"))
				);
		addToCart.click();

		try {
			// Tìm danh sách các phần tử phù hợp
			WebElement toastMessages = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='toast-message']")));
			String expectedMessage = "Đã thêm vào giỏ hàng";
            String actualMessage = toastMessages.getText();
            if (actualMessage.equals(expectedMessage)) {
                System.out.println("BUG: Số lượng 0 nhưng vẫn thêm giỏ hàng được.");
            } else {
            	System.out.println("Thông báo: Lỗi số lượng phải từ 1 trở lên");
            }
		} catch (Exception e) {
			System.out.println("BUG");
		}

	}
	
	@Test
	@Order(7)
	public void testThemSanPhamCT2() throws InterruptedException {
		System.out.println("Test thêm sản phẩm khi đăng nhập ở trang chi tiết.");
		Thread.sleep(2000); // Nghỉ 2 giây

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		
        WebElement iconPerson = driver.findElement(By.xpath("//a[@class='header__account--btn preson']"));
        iconPerson.click();

        WebElement usernameField = driver.findElement(By.xpath("//input[@placeholder='Email']"));
        usernameField.sendKeys("huavanthao20102016@gmail.com");

        WebElement passwordField = driver.findElement(By.xpath("//input[@placeholder='Password']"));
        passwordField.sendKeys("123456");

        WebElement loginButton = driver.findElement(By.xpath("//button[@class='account__login--btn primary__btn']"));
        loginButton.click();
        
        Thread.sleep(2000);
        
        WebElement clickTC = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='header__menu--link text-white TC']"))
				);
        clickTC.click();
        
        Thread.sleep(2000); 
        
        WebElement clickSP = driver.findElement(By.xpath("//a[@class='product__card--thumbnail__link display-block CT']"));
		clickSP.click();
		
		Thread.sleep(2000);
		
		WebElement addToCart = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='primary__btn quickview__cart--btn add']"))
				);
		addToCart.click();
		
		Thread.sleep(9000);
		
		WebElement clickGH = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='header__account--btn minicart__open--btn']"))
				);
        clickGH.click();
		
        Thread.sleep(2000);
        
		WebElement numberElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@class='quantity__number']")));
		
		Thread.sleep(2000);
		// Lấy giá trị hiện tại của số lượng
	    int currentQuantity = Integer.parseInt(numberElement.getAttribute("value"));
	    System.out.println("Giá trị ban đầu: " + currentQuantity);
	    
	    WebElement clickClose = driver.findElement(By.xpath("// button[@class='minicart__close--btn']"));
		clickClose.click();
		
		Thread.sleep(2000);
		
		addToCart.click();

		Thread.sleep(9000);
		
		clickGH.click();
		
		Thread.sleep(2000);
		
		// Làm mới phần tử `numberElement` sau khi click
	    numberElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@class='quantity__number']")));
	    int newQuantity = Integer.parseInt(numberElement.getAttribute("value"));
	    System.out.println("Giá trị sau khi click: " + newQuantity);
	       
		try {
			 // Kiểm tra kết quả
			if (newQuantity == currentQuantity + 1) {
		        System.out.println("Số lượng sản phẩm sẽ được cộng dồn thành công và có thông báo");
		    } else {
		        System.out.println("BUG: Số lượng sản phẩm không được cộng dồn");
		    }
		} catch (Exception e) {
			System.out.println("BUG");
		}

	}
	
	@Test
	@Order(8)
	public void testXoaSanPham() throws InterruptedException {
		System.out.println("Test xoá sản phẩm.");
		Thread.sleep(2000); // Nghỉ 2 giây

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		
        WebElement iconPerson = driver.findElement(By.xpath("//a[@class='header__account--btn preson']"));
        iconPerson.click();

        WebElement usernameField = driver.findElement(By.xpath("//input[@placeholder='Email']"));
        usernameField.sendKeys("huavanthao20102016@gmail.com");

        WebElement passwordField = driver.findElement(By.xpath("//input[@placeholder='Password']"));
        passwordField.sendKeys("123456");

        WebElement loginButton = driver.findElement(By.xpath("//button[@class='account__login--btn primary__btn']"));
        loginButton.click();
        
        Thread.sleep(2000);
        
        WebElement clickTC = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='header__account--btn minicart__open--btn']"))
				);
        clickTC.click();
        
        Thread.sleep(2000); 
        
        WebElement clickSP = driver.findElement(By.xpath("//button[@class='minicart__product--remove']"));
		clickSP.click();

		try {
			// Tìm danh sách các phần tử phù hợp
			WebElement toastMessages = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='toast-message']")));
			String expectedMessage = "Đã Xóa Thành Công";
            String actualMessage = toastMessages.getText();
            if (actualMessage.equals(expectedMessage)) {
                System.out.println("Không có bug. Thông báo hiển thị đúng: " + actualMessage);
            } else {
            	System.out.println("BUG: Không hiện thông báo đã xoá thành công");
            }
		} catch (Exception e) {
			System.out.println("BUG");
		}

	}
	
	@AfterEach
	public void tearDown() throws InterruptedException {
		Thread.sleep(2000); // Nghỉ 2 giây sau mỗi test
		driver.quit();
	}

}
