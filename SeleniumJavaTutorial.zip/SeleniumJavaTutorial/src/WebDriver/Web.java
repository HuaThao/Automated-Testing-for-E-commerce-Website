package WebDriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class Web {
    public static void main(String[] args) {
        // Đặt đường dẫn đến msedgedriver
        System.setProperty("webdriver.edge.driver", "D:/msedgedriver/msedgedriver.exe");

        // Cấu hình EdgeOptions
        EdgeOptions options = new EdgeOptions();
        options.addArguments("start-maximized"); // Khởi động với cửa sổ tối đa
        options.addArguments("disable-infobars"); // Tắt các thông báo trong trình duyệt

        // Khởi tạo EdgeDriver với các tùy chọn
        WebDriver driver = new EdgeDriver(options);

        // Truy cập vào URL
        driver.get("http://127.0.0.1:8000");

        // In ra tiêu đề trang
        System.out.println("Title: " + driver.getTitle());

        // Đóng trình duyệt
        
    }
}
